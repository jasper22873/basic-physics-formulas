# __Basic Physics Formulas__

### This python package consists of some physics formulas like formula for acceleration,density,newton second law,kinetic energy,average speed ,power,ohms law,gravitational force,orbital velocity and acceleration due to gravity.



## Contributor

### JASPER KIRUBAKARAN J

## Mentor

### Vidhya Lakshmi 